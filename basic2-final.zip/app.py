
import streamlit as st

st.title("📊 기후 데이터 대시보드")

st.markdown("왼쪽 메뉴에서 원하는 항목을 선택하세요.")
